function X = remap(X,old,new)

X = sdpvarremap(X,old,new);